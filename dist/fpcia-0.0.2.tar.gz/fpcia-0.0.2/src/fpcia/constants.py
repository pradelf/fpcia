import numpy as np

# For reproducibility
RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)